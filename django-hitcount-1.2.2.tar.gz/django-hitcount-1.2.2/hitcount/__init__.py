from __future__ import unicode_literals

VERSION = (1, 2, 2)

__version__ = '.'.join(str(i) for i in VERSION)
